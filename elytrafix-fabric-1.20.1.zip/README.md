# Elytra Fix (Fabric 1.20.1, sadece client)

Elytra ile uçarken bir bloğa/duvara bakarken de firework ile hızlanmanı sağlar.

- Sohbette `/01` yaz -> mod AÇIK
- Sohbette `/02` yaz -> mod KAPALI
- Varsayılan: kapalı. Sunucuya kurmana gerek yok, sadece sende kurulu olsun.
- Gerekenler: Minecraft 1.20.1, Fabric Loader 0.15+, Fabric API

## GitHub'da derleme
1. Yeni bir repo aç, bu klasörün içindekileri (`.github` dahil) repoya yükle.
2. Repo -> Actions sekmesi -> "build" çalışır (ya da "Run workflow").
3. Bitince çalıştırmaya tıkla -> en altta Artifacts -> `elytrafix-jar` indir.
4. Zip'in içindeki `elytrafix-1.0.0.jar` dosyasını `mods` klasörüne at (Fabric API ile birlikte).
