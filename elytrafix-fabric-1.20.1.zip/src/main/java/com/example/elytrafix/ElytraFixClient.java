package com.example.elytrafix;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ElytraFixClient implements ClientModInitializer {

    /** Sohbette /01 yazinca true, /02 yazinca false olur. Varsayilan: kapali. */
    public static volatile boolean enabled = false;

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("01").executes(ctx -> {
                enabled = true;
                ctx.getSource().sendFeedback(Text.literal("Elytra Fix: AÇIK").formatted(Formatting.GREEN));
                return 1;
            }));

            dispatcher.register(ClientCommandManager.literal("02").executes(ctx -> {
                enabled = false;
                ctx.getSource().sendFeedback(Text.literal("Elytra Fix: KAPALI").formatted(Formatting.RED));
                return 1;
            }));
        });
    }
}
