package com.example.elytrafix.mixin;

import com.example.elytrafix.ElytraFixClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.FireworkRocketItem;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {

    /**
     * Vanilla'da ucarken bloga bakip firework'e sag tiklarsan sunucuya "bloga kullan"
     * paketi gider ve roket blokta patlar, boost almazsin. Burada o paketi hic
     * gondermeden, yerine "havada esya kullan" paketini gonderiyoruz.
     * Sunucu vanilla kalabilir: sadece client'ta kurulu olmasi yeterli.
     */
    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void elytrafix$useFireworkInAir(ClientPlayerEntity player, Hand hand, BlockHitResult hitResult,
                                            CallbackInfoReturnable<ActionResult> cir) {
        if (!ElytraFixClient.enabled) return;
        if (!player.isFallFlying()) return;
        if (!(player.getStackInHand(hand).getItem() instanceof FireworkRocketItem)) return;

        ClientPlayerInteractionManager self = (ClientPlayerInteractionManager) (Object) this;
        ActionResult result = self.interactItem(player, hand);
        cir.setReturnValue(result == ActionResult.PASS ? ActionResult.FAIL : result);
    }
}
